package com.example.samuraitravel.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class WebSecurityConfig {

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http
				.authorizeHttpRequests((requests) -> requests
						.requestMatchers("/css/**", "/images/**", "/js/**", "/storage/**", "/", "/signup/**", "/houses",
								"/houses/{id}", "/stripe/webhook", "/houses/{id}/reviews")

						// すべてのユーザーがアクセスできる
						.permitAll()

						// 管理者にのみアクセスできる。
						.requestMatchers("/admin/**").hasRole("ADMIN")

						// ログインが必要誰でもできる。
						.anyRequest().authenticated())
				.formLogin((form) -> form

						// ログインページ
						.loginPage("/login")

						// ログインフォームの送信先
						.loginProcessingUrl("/login")

						// ログイン成功時のリダイレクト
						.defaultSuccessUrl("/?loggedIn")

						// ログイン失敗時のリダイレクト先
						.failureUrl("/login?error")
						.permitAll())
				.logout((logout) -> logout

						// ログアウト時のリダイレクト先
						.logoutSuccessUrl("/?loggedOut")
						.permitAll())
				.csrf().ignoringRequestMatchers("/stripe/webhook");

		return http.build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}